# Test repeat/until
var i = 0
repeat { i = i + 1 } until i >= 3
print(i)