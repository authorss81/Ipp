# Test while vs do-while
var i = 0
while i < 3 { i = i + 1 }
print(i)